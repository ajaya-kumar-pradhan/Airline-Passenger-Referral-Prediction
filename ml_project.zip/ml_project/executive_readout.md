# Executive Readout: Therapy Discontinuation Prediction

## Project Goal
Develop a data-driven approach to focus field support capacity on patients most likely to discontinue specialty therapy within 60 days.

## Model Performance
- **Primary Model**: XGBoost Classifier
- **ROC-AUC**: **0.9677**
- **Recall (Positive Class)**: **84%** (Successfully identifies 84% of patients who will actually discontinue)
- **Precision (Positive Class)**: **75%**

## Key Drivers (Insights)
Based on SHAP analysis, the top predictors for discontinuation are:
1.  **Days Since Previous Shipment**: A longer gap than the typical 30-day supply strongly indicates early signs of abandonment.
2.  **Number of Refill Rejections**: Patients experiencing multiple rejected refills are significantly more likely to give up on therapy due to access friction.
3.  **Historical Discontinuation Rate (Site/HCP)**: Regional and site-level history provides crucial context for patient success.
4.  **Support Call Volume**: A sudden spike in support calls often correlates with unresolved friction or confusion.

## Business Actions & Recommendations
1.  **Prioritized Outreach**: Field support teams should prioritize the top 100 patients identified in the `high_risk_patients.csv` list.
2.  **Early Intervention**: For patients with even a single refill rejection, trigger an automated support follow-up to assist with payer navigation.
3.  **Site Support**: Target training for sites with high historical discontinuation rates to improve their coordination with specialty pharmacies.

## Deliverables
- Final Model: `model_xgb.joblib`
- High-Risk Patient List: [high_risk_patients.csv](file:///C:/Users/ajaya/.gemini/antigravity/scratch/ml_project/high_risk_patients.csv)
- Feature Engineering Pipeline: `feature_engineering.py`
