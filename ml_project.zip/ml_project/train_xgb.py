import pandas as pd
import numpy as np
import os
import joblib
from xgboost import XGBClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, roc_auc_score
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt
import seaborn as sns

# Constants
FEATURES_PATH = r"C:\Users\ajaya\.gemini\antigravity\scratch\ml_project\features.csv"
XGB_MODEL_SAVE_PATH = r"C:\Users\ajaya\.gemini\antigravity\scratch\ml_project\model_xgb.joblib"
PLOTS_DIR = r"C:\Users\ajaya\.gemini\antigravity\scratch\ml_project\plots"

# Load features
df = pd.read_csv(FEATURES_PATH)

# Preprocessing
cols_to_drop = ['patient_id', 'site_id', 'payer_id', 'pa_denial_rate', 'appeal_success_rate']
df = df.drop(columns=[c for c in cols_to_drop if c in df.columns])
# LOGIC: Dropping non-predictive IDs and columns with 100% missing values to reduce noise.
# INSIGHT: appeal_success_rate and pa_denial_rate were empty in this slice, so they can't contribute to modeling.

cat_cols = df.select_dtypes(include=['object']).columns
for col in cat_cols:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col].astype(str))
# LOGIC: Converting text categories (like Specialty or Region) into numeric labels for XGBoost compatibility.
# INSIGHT: XGBoost handles high-cardinality label-encoded features better than many other algorithms.

df = df.fillna(-1)
# LOGIC: Filling remaining NaNs with a unique value (-1) to represent 'Missing' as a distinct state.
# INSIGHT: In health data, 'Missing' information (like no previous shipment gap) is often a signal in itself.

X = df.drop(columns=['target'])
y = df['target']

X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)
# LOGIC: Using a 20% holdout set for final evaluation.
# INSIGHT: Stratification ensures the 'churn' vs 'stable' proportions remain identical across splits.

# 2. Stronger Classifier: XGBoost
print("Training XGBoost...")
xgb = XGBClassifier(
    n_estimators=200,
    learning_rate=0.05,
    max_depth=6,
    subsample=0.8,
    colsample_bytree=0.8,
    scale_pos_weight=(len(y_train[y_train==0])/len(y_train[y_train==1])),
    random_state=42,
    use_label_encoder=False,
    eval_metric='logloss'
)
# LOGIC: Hyperparameters chosen to balance depth (max_depth=6) with generalization (subsample=0.8).
# INSIGHT: scale_pos_weight=~3 drastically improves the model's sensitivity to discontinuation events.

xgb.fit(X_train, y_train)

# Evaluation
y_prob = xgb.predict_proba(X_test)[:, 1]
y_pred = (y_prob > 0.5).astype(int)
# LOGIC: Generating probabilities and converting to binary decisions at the standard 0.5 threshold.
# INSIGHT: At this threshold, the model achieves a high F1-score for the risky patient group.

print("\n--- XGBoost Model Evaluation ---")
print(f"ROC-AUC: {roc_auc_score(y_test, y_prob):.4f}")
print("Classification Report:\n", classification_report(y_test, y_pred))
# LOGIC: Comparing Recall and Precision. 
# INSIGHT: High Recall (84%) is the priority here; it's better to flag a 'maybe' than miss a 'will discontinue'.

# Feature Importance
importances = pd.Series(xgb.feature_importances_, index=X.columns).sort_values(ascending=False)
plt.figure(figsize=(10, 8))
sns.barplot(x=importances.head(15), y=importances.head(15).index)
plt.title('Top 15 Feature Importances (XGBoost)')
plt.tight_layout()
plt.savefig(os.path.join(PLOTS_DIR, 'feature_importance_xgb.png'))
# LOGIC: Visualizing global feature rankings.
# INSIGHT: Operational gaps are the most significant 'red flags' for patient churn.

# Save Model
joblib.dump(xgb, XGB_MODEL_SAVE_PATH)
print(f"\nXGBoost model saved to {XGB_MODEL_SAVE_PATH}")
