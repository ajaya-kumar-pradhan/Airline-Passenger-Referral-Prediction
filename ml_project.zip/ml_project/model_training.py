import pandas as pd
import numpy as np
import os
import joblib
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, roc_auc_score, precision_recall_curve, auc
from sklearn.preprocessing import LabelEncoder
import matplotlib.pyplot as plt
import seaborn as sns

# Constants
FEATURES_PATH = r"C:\Users\ajaya\.gemini\antigravity\scratch\ml_project\features.csv"
MODEL_SAVE_PATH = r"C:\Users\ajaya\.gemini\antigravity\scratch\ml_project\model.joblib"
PLOTS_DIR = r"C:\Users\ajaya\.gemini\antigravity\scratch\ml_project\plots"
os.makedirs(PLOTS_DIR, exist_ok=True)

# Load features
df = pd.read_csv(FEATURES_PATH)

# Drop high cardinality IDs and null-only columns
cols_to_drop = ['patient_id', 'site_id', 'payer_id', 'pa_denial_rate', 'appeal_success_rate']
df = df.drop(columns=[c for c in cols_to_drop if c in df.columns])

# Handle Categorical variables
cat_cols = df.select_dtypes(include=['object']).columns
for col in cat_cols:
    le = LabelEncoder()
    df[col] = le.fit_transform(df[col].astype(str))

# Handle Missing values
df = df.fillna(-1)

# Split features and target
X = df.drop(columns=['target'])
y = df['target']

# Train/Test Split
# Note: For real enterprise apps, we'd split by patient_id if there were multiple anchors per patient.
# Here, there's 1 anchor per patient, so a simple split is fine.
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42, stratify=y)

# 1. Baseline Model: Random Forest
print("Training Baseline Random Forest...")
rf = RandomForestClassifier(n_estimators=100, random_state=42, class_weight='balanced')
rf.fit(X_train, y_train)

# Evaluation
y_pred = rf.predict(X_test)
y_prob = rf.predict_proba(X_test)[:, 1]

print("\n--- Model Evaluation ---")
print(f"ROC-AUC: {roc_auc_score(y_test, y_prob):.4f}")
print("Classification Report:\n", classification_report(y_test, y_pred))

# Feature Importance
importances = pd.Series(rf.feature_importances_, index=X.columns).sort_values(ascending=False)
plt.figure(figsize=(10, 8))
sns.barplot(x=importances.head(15), y=importances.head(15).index)
plt.title('Top 15 Feature Importances (Baseline RF)')
plt.tight_layout()
plt.savefig(os.path.join(PLOTS_DIR, 'feature_importance_rf.png'))

# Save Model
joblib.dump(rf, MODEL_SAVE_PATH)
print(f"\nModel saved to {MODEL_SAVE_PATH}")

# Save feature list for inference
joblib.dump(X.columns.tolist(), r"C:\Users\ajaya\.gemini\antigravity\scratch\ml_project\feature_list.joblib")
