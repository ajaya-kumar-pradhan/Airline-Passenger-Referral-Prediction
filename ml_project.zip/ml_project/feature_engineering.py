import pandas as pd
import numpy as np
import os

data_dir = r"C:\Users\ajaya\Downloads\ml project"
output_path = r"C:\Users\ajaya\.gemini\antigravity\scratch\ml_project\features.csv"

# Load data
events = pd.read_csv(os.path.join(data_dir, "events_status_shipments.csv"))
hcps = pd.read_csv(os.path.join(data_dir, "hcps_master.csv"))
payers = pd.read_csv(os.path.join(data_dir, "payers_master.csv"))

# Convert dates
events['event_timestamp'] = pd.to_datetime(events['event_timestamp'])

# Filter only events up to and including anchor
# Although the prompt says anchor rows are the points in time, 
# for each patient we should only use info before or on their specific anchor timestamp.
anchors = events[events['is_prediction_anchor'] == 1].copy()

# Sort events to ensure time order
events = events.sort_values(['patient_id', 'event_timestamp'])

# Function to extract features for a set of patients at anchor
def get_features(events_df, anchor_rows, hcps_df, payers_df):
    features_list = []
    
    for _, anchor in anchor_rows.iterrows():
        pid = anchor['patient_id']
        anchor_time = anchor['event_timestamp']
        
        # Historical events for this patient
        history = events_df[(events_df['patient_id'] == pid) & (events_df['event_timestamp'] <= anchor_time)]
        # LOGIC: Crucial 'Point-in-Time' enforcement. Only data AT or BEFORE anchor is used.
        # INSIGHT: Prevents data leakage where future events might accidentally 'tell' the model the outcome.
        
        # Basic Info
        f = {
            'patient_id': pid,
            'age_band': anchor['patient_age_band'],
            'gender': anchor['patient_gender'],
            'target': anchor['discontinued_within_60d'],
            'site_id': anchor['site_id'],
            'payer_id': anchor['payer_id']
        }
        # LOGIC: Capturing baseline patient and geographical context.
        # INSIGHT: Demographic factors often correlate with therapy persistence.
        
        # 1. Refill Cadence
        shipments = history[history['event_type'] == 'Shipment_Released']
        if len(shipments) > 0:
            f['num_shipments'] = len(shipments)
            f['avg_days_supply'] = shipments['days_supply'].mean()
            f['last_days_supply'] = shipments['days_supply'].iloc[-1]
            # LOGIC: Tracking volume and supply consistency.
            # INSIGHT: Irregular supply amounts frequently precede discontinuation.
            
            # Days since previous shipment (excluding the current anchor shipment)
            if len(shipments) > 1:
                f['days_since_prev_shipment'] = (anchor_time - shipments['event_timestamp'].iloc[-2]).days
                # Calculate gaps between all previous shipments
                gaps = shipments['event_timestamp'].diff().dt.days.dropna()
                f['avg_shipment_gap'] = gaps.mean()
                f['std_shipment_gap'] = gaps.std()
                # LOGIC: Measuring the 'rhythm' of refills.
                # INSIGHT: High variability in shipment gaps is a primary indicator of patient struggle.
            else:
                f['days_since_prev_shipment'] = np.nan
                f['avg_shipment_gap'] = np.nan
                f['std_shipment_gap'] = np.nan
                
            f['total_days_on_therapy'] = (anchor_time - shipments['event_timestamp'].iloc[0]).days
            # LOGIC: Calculating the 'experience' level of the patient with the therapy.
            # INSIGHT: Newer patients often have higher 'early leak' rates.
        else:
            f['num_shipments'] = 0
            f['avg_days_supply'] = np.nan
            f['last_days_supply'] = np.nan
            f['days_since_prev_shipment'] = np.nan
            f['avg_shipment_gap'] = np.nan
            f['std_shipment_gap'] = np.nan
            f['total_days_on_therapy'] = 0

        # 2. Access Friction
        # Count explicit Refill_Rejected events OR flags
        f['num_rejections'] = ((history['event_type'] == 'Refill_Rejected') | (history['refill_rejected_flag'] == 1)).sum()
        f['num_payer_changes'] = (history['event_type'] == 'Payer_Changed').sum()
        # LOGIC: Aggregating structural hurdles (payer switches, claim rejections).
        # INSIGHT: Access friction is the #1 administrative reason for discontinuation.
        
        rejections = history[(history['event_type'] == 'Refill_Rejected') | (history['refill_rejected_flag'] == 1)]
        if len(rejections) > 0:
            f['days_since_last_rejection'] = (anchor_time - rejections['event_timestamp'].iloc[-1]).days
            # LOGIC: Checking the recency of friction.
            # INSIGHT: A recent rejection has a much higher 'churn' impact than one from 6 months ago.
        else:
            f['days_since_last_rejection'] = 999 # Large value if no rejections
            
        # 3. Support
        f['num_support_calls'] = (history['event_type'] == 'Support_Call').sum()
        # LOGIC: Quantifying engagement with support teams.
        # INSIGHT: Support calls can be reactive (solving a problem) or proactive (preventing churn).
        
        # 4. Status
        status_changes = history[history['event_type'] == 'Status_Changed']
        f['num_status_changes'] = len(status_changes)
        # LOGIC: Tracking clinical/administrative status volatility.
        # INSIGHT: Frequent status changes often signal a patient 'trapped' in administrative loops.
        
        features_list.append(f)
        
    feat_df = pd.DataFrame(features_list)
    
    # Merge Master Data
    feat_df = feat_df.merge(hcps_df, on='site_id', how='left')
    feat_df = feat_df.merge(payers_df, on='payer_id', how='left')
    # LOGIC: Enriching patient data with Site (HCP) and Payer environmental factors.
    # INSIGHT: Regional behavior and specific payer segments (e.g., Government) have distinct discontinuation profiles.
    
    return feat_df

# Execute feature extraction
print("Extracting features...")
final_features = get_features(events, anchors, hcps, payers)
final_features.to_csv(output_path, index=False)
print(f"Features saved to {output_path}. Shape: {final_features.shape}")
