import pandas as pd
import os

data_dir = r"C:\Users\ajaya\Downloads\ml project"
files = ["events_status_shipments.csv", "hcps_master.csv", "payers_master.csv"]

for file in files:
    path = os.path.join(data_dir, file)
    print(f"--- {file} ---")
    df = pd.read_csv(path, nrows=5)
    print("Columns:", df.columns.tolist())
    print("Sample:\n", df.head())
    
    # Get total row count and null info
    full_df = pd.read_csv(path)
    print("Shape:", full_df.shape)
    print("Null values:\n", full_df.isnull().sum())
    print("\n")

# Try to read the data dictionary if possible
try:
    dict_df = pd.read_excel(os.path.join(data_dir, "case_study_data_dictionary.xlsx"))
    print("--- Data Dictionary ---")
    print(dict_df)
except Exception as e:
    print(f"Could not read Excel dictionary: {e}")
