import pandas as pd
import numpy as np
import os
import joblib
import shap
import matplotlib.pyplot as plt

# Constants
FEATURES_PATH = r"C:\Users\ajaya\.gemini\antigravity\scratch\ml_project\features.csv"
XGB_MODEL_PATH = r"C:\Users\ajaya\.gemini\antigravity\scratch\ml_project\model_xgb.joblib"
PLOTS_DIR = r"C:\Users\ajaya\.gemini\antigravity\scratch\ml_project\plots"

# Load data and model
df = pd.read_csv(FEATURES_PATH)
xgb_model = joblib.load(XGB_MODEL_PATH)

# Preprocessing (same as training)
cols_to_drop = ['patient_id', 'site_id', 'payer_id', 'pa_denial_rate', 'appeal_success_rate']
df_proc = df.drop(columns=[c for c in cols_to_drop if c in df.columns])

from sklearn.preprocessing import LabelEncoder
cat_cols = df_proc.select_dtypes(include=['object']).columns
for col in cat_cols:
    le = LabelEncoder()
    df_proc[col] = le.fit_transform(df_proc[col].astype(str))

df_proc = df_proc.fillna(-1)
X = df_proc.drop(columns=['target'])

# SHAP Analysis
print("Calculating SHAP values...")
explainer = shap.TreeExplainer(xgb_model)
shap_values = explainer.shap_values(X)

# Summary Plot
plt.figure()
shap.summary_plot(shap_values, X, show=False)
plt.tight_layout()
plt.savefig(os.path.join(PLOTS_DIR, 'shap_summary.png'))
plt.close()

# Identification of High Risk Patients
# Generate probabilities for everyone
probs = xgb_model.predict_proba(X)[:, 1]
df['discontinuation_probability'] = probs

# Sort by risk
high_risk_patients = df.sort_values(by='discontinuation_probability', ascending=False)
high_risk_patients.to_csv(r"C:\Users\ajaya\.gemini\antigravity\scratch\ml_project\high_risk_patients.csv", index=False)

print(f"SHAP plots saved to {PLOTS_DIR}")
print("High risk patient list generated.")
