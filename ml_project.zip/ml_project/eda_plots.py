import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns
import os

# Set plotting style
sns.set_theme(style="whitegrid")

data_dir = r"C:\Users\ajaya\Downloads\ml project"
output_dir = r"C:\Users\ajaya\.gemini\antigravity\scratch\ml_project\plots"
os.makedirs(output_dir, exist_ok=True)

# Load data
events = pd.read_csv(os.path.join(data_dir, "events_status_shipments.csv"))
hcps = pd.read_csv(os.path.join(data_dir, "hcps_master.csv"))
payers = pd.read_csv(os.path.join(data_dir, "payers_master.csv"))

# Convert dates
events['event_timestamp'] = pd.to_datetime(events['event_timestamp'])
events['expected_refill_due_date'] = pd.to_datetime(events['expected_refill_due_date'])

# 1. Target Distribution
plt.figure(figsize=(8, 5))
anchor_rows = events[events['is_prediction_anchor'] == 1]
sns.countplot(data=anchor_rows, x='discontinued_within_60d')
plt.title('Distribution of Discontinuation within 60 Days')
plt.savefig(os.path.join(output_dir, 'target_distribution.png'))

print(f"Target distribution:\n{anchor_rows['discontinued_within_60d'].value_counts(normalize=True)}")

# 2. Event Types
plt.figure(figsize=(12, 6))
sns.countplot(data=events, y='event_type', order=events['event_type'].value_counts().index)
plt.title('Frequency of Event Types')
plt.tight_layout()
plt.savefig(os.path.join(output_dir, 'event_types.png'))

# 3. Patient Demographics (Age Band & Gender)
plt.figure(figsize=(14, 5))
plt.subplot(1, 2, 1)
sns.countplot(data=anchor_rows, x='patient_age_band')
plt.title('Patient Age Band')
plt.subplot(1, 2, 2)
sns.countplot(data=anchor_rows, x='patient_gender')
plt.title('Patient Gender')
plt.savefig(os.path.join(output_dir, 'demographics.png'))

# 4. Access Friction (Refill Rejections)
rejections = events[events['refill_rejected_flag'] == 1]
print(f"Number of refill rejections: {len(rejections)}")

# 5. Missing Values Analysis
missing = events.isnull().sum() / len(events) * 100
print(f"Missing values (%):\n{missing[missing > 0]}")

# 6. Basic Time Trends
events['month_year'] = events['event_timestamp'].dt.to_period('M')
plt.figure(figsize=(12, 6))
events.groupby('month_year').size().plot(kind='line')
plt.title('Event Volume Over Time')
plt.savefig(os.path.join(output_dir, 'volume_over_time.png'))

print("EDA complete. Plots saved to", output_dir)
